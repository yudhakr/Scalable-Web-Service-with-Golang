Assignment 2 FGA Kominfo Hacktiv
Azka Nurhuda