package router

type Router interface {
	Routers()
}
